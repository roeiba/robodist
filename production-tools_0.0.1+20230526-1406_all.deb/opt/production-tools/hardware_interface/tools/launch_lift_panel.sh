#!/bin/bash

# Locate console_tools, releative to the path containing this script ($0)
SCRIPT_DIR=$(dirname $(readlink -f $0))
PRODUCTION_TOOLS_BASE=$(readlink -f $SCRIPT_DIR/../..) # Update if moved to shallow/deeper dir

ARCH=`dpkg --print-architecture`

if [ "${ARCH}" == "amd64" ]
then
    INTERFACE="can0"
else
    INTERFACE="can1"
fi

source $PRODUCTION_TOOLS_BASE/console_tools/can_tools.bash --source-only

configure_can ${INTERFACE} 250000
status=$?

if [ $status -eq 1 ]
then
    exit 1
fi

LAUNCH_PATH=$(which launch_lift_panel.py)
if [[ $? != 0 ]]; then
    ipython3 -i $PRODUCTION_TOOLS_BASE/hardware_interface/tools/launch_lift_panel.py
else
    ipython3 -i $LAUNCH_PATH
fi

exit 0