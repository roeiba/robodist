#!/bin/bash

# Locate production tools base folder, releative to the path containing this script ($0)
SCRIPT_DIR=$(dirname $(readlink -f $0))
PRODUCTION_TOOLS_BASE=$(readlink -f $SCRIPT_DIR/..) # Update if moved to shallow/deeper dir

source $PRODUCTION_TOOLS_BASE/console_tools/can_tools.bash --source-only

configure_can can0 250000
status=$?

if [ $status -eq 1 ]
then
    exit 1
fi

which test_ui_board.py
if ! command -v test_ui_board.py &> /dev/null
then
    python test_ui_board.py
else
    test_ui_board.py
fi

