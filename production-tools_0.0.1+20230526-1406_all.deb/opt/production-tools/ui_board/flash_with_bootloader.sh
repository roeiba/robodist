#!/bin/bash

# Locate production tools base folder, releative to the path containing this script ($0)
SCRIPT_DIR=$(dirname $(readlink -f $0))
PRODUCTION_TOOLS_BASE=$(readlink -f $SCRIPT_DIR/..) # Update if moved to shallow/deeper dir

source $PRODUCTION_TOOLS_BASE/console_tools/can_tools.bash --source-only

configure_can can0 250000
status=$?

if [ $status -eq 1 ]
then
    exit 1
fi

sleep 5

ARCH=$(arch)
if [[ "$ARCH" == "x86_64" ]]; then
    $PRODUCTION_TOOLS_BASE/tools/openblt_${OPENBLT_VERSION}_src_amd64/Host/BootCommander -s=xcp -t=xcp_can -d=can0 -c=0 -b=250000 -tid=502 -rid=482 $PRODUCTION_TOOLS_BASE/ui_board/firmware/ui_board__sw-pn-0201-01-01_1.2.0.srec
else
    $PRODUCTION_TOOLS_BASE/tools/openblt_arm64/Host/BootCommander -s=xcp -t=xcp_can -d=can0 -c=0 -b=250000 -tid=502 -rid=482 $PRODUCTION_TOOLS_BASE/ui_board/firmware/ui_board__sw-pn-0201-01-01_1.2.0.srec
fi

status=$?

if [ $status -eq 1 ]
then
    print_colour $RED "\n\n\nerror attempting to flash the firmware UI board, please check the message for the error"
    exit 1
fi

print_colour $GREEN "\n\n\n\nFLASH COMPLETED SUCCESSFULLY"
exit 0