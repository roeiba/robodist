#!/bin/bash

printf "Initialising flashing\n"

# Locate console_tools, releative to the path containing this script ($0)
SCRIPT_DIR=$(dirname $(readlink -f $0))
PRODUCTION_TOOLS_BASE=$(readlink -f $SCRIPT_DIR/../..) # Update if moved to shalowe/deeper dir

source $PRODUCTION_TOOLS_BASE/config.cfg
source $PRODUCTION_TOOLS_BASE/console_tools/print_tools.bash --source-only
source $PRODUCTION_TOOLS_BASE/console_tools/test_tools.bash --source-only

PW=$(echo $WEMO_ACCESS | base64 -d | gpg --decrypt --pinentry-mode loopback --passphrase $GPG_PASSPHRASE 2>/dev/null)

test_internal

echo $PW | sudo -S systemctl stop batt_pipe_to_wemofm.service

ARCH=$(arch)
if [[ "$ARCH" == "x86_64" ]]; then
    ARCH_PATH=$PRODUCTION_TOOLS_BASE/tools/openblt_${OPENBLT_VERSION}_src_amd64
else
    ARCH_PATH=$PRODUCTION_TOOLS_BASE/tools/openblt_arm64
fi

LD_LIBRARY_PATH=$ARCH_PATH/Host/


if ! command -v smart_upgrader.py &> /dev/null
then
    python3 $PRODUCTION_TOOLS_BASE/upgraders/scripts/smart_upgrader.py --b $PRODUCTION_TOOLS_BASE --p $ARCH_PATH -c $PRODUCTION_TOOLS_BASE/upgraders/config/config.yaml -i $PRODUCTION_TOOLS_BASE/upgraders/config/interfaces.yaml
else
    smart_upgrader.py --b $PRODUCTION_TOOLS_BASE --p $ARCH_PATH -c $PRODUCTION_TOOLS_BASE/upgraders/config/config.yaml -i $PRODUCTION_TOOLS_BASE/upgraders/config/interfaces.yaml
fi

status=$?

if [ $status -eq 1 ]
then
    print_colour $RED "\n\n\nupgrade failed, check the messages abve to identify the error"
    exit 1
fi

echo $PW | sudo -S systemctl start robohive_wemo_platform_node.service

print_colour $GREEN "\n\n\n\nUpgrade completed"
exit 0
