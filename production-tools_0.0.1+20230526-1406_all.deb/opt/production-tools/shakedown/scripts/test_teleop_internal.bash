#!/bin/bash

source ../../config.cfg

PW=$(echo $WEMO_ACCESS | base64 -d | gpg --decrypt --pinentry-mode loopback --passphrase $GPG_PASSPHRASE 2>/dev/null)

echo $PW | sudo -S systemctl restart robohive_mobility_driver_node.service
echo $PW | sudo -S systemctl restart robohive_mobility_safety_node.service
echo $PW | sudo -S systemctl restart robohive_wemo_platform_node.service

export TERMINFO=/opt/wemo/share/terminfo
source /opt/wemo/setup.sh
robohive_keyboard_teleop_console