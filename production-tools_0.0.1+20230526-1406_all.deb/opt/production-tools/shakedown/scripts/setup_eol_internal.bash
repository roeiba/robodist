#!/bin/bash

# Locate production tools base folder, releative to the path containing this script ($0)
SCRIPT_DIR=$(dirname $(readlink -f $0))
PRODUCTION_TOOLS_BASE=$(readlink -f $SCRIPT_DIR/../..) # Update if moved to shallow/deeper dir

source $PRODUCTION_TOOLS_BASE/config.cfg --source-only
source $PRODUCTION_TOOLS_BASE/console_tools/can_tools.bash --source-only

PW=$(echo $WEMO_ACCESS | base64 -d | gpg --decrypt --pinentry-mode loopback --passphrase $GPG_PASSPHRASE 2>/dev/null)

ARCH=$(arch)
if [[ "$ARCH" == "x86_64" ]]; then
    ARCH_PATH=$PRODUCTION_TOOLS_BASE/tools/openblt_${OPENBLT_VERSION}_src_amd64
else
    ARCH_PATH=$PRODUCTION_TOOLS_BASE/tools/openblt_arm64
fi

if ! command -v battery_level_check.py &> /dev/null
then
    python $PRODUCTION_TOOLS_BASE/hardware_interface/examples/battery_level_check.py -b 50
else
    battery_level_check.py -b 50
fi

status=$?

if [ $status -eq 1 ]
then
    print_colour $RED "\n\n\nbattery level is under the desired value, please charge the robot and try later"
    exit 1
fi

printf "Initialising flashing\n"

echo $PW | sudo -S systemctl stop robohive_wemo_platform_node.service

configure_can can1 250000
status=$?

if [ $status -eq 1 ]
then
    exit 1
fi

if ! command -v smart_upgrader.py &> /dev/null
then
    python3 $PRODUCTION_TOOLS_BASE/upgraders/scripts/smart_upgrader.py --b $PRODUCTION_TOOLS_BASE --p $ARCH_PATH -c $PRODUCTION_TOOLS_BASE/upgraders/config/config.yaml -i $PRODUCTION_TOOLS_BASE/upgraders/config/interfaces.yaml
else
    smart_upgrader.py --b $PRODUCTION_TOOLS_BASE --p $ARCH_PATH -c $PRODUCTION_TOOLS_BASE/upgraders/config/config.yaml -i $PRODUCTION_TOOLS_BASE/upgraders/config/interfaces.yaml
fi

status=$?

if [ $status -ne 0 ]
then
    print_colour $RED "\n\n\nupgrade failed, check the messages above to identify the error"
fi

if [ $status -eq 1 ]
then
    exit 1
fi

if ! command -v configure_motor_controller.py &> /dev/null
then
    python3 $PRODUCTION_TOOLS_BASE/cpm/scripts/configure_motor_controller.py
else
    configure_motor_controller.py
fi

status=$?

if [ $status -eq 1 ]
then
    print_colour $RED "\n\n\nerror setting up the motor controllers, check the messages above to identify the error"
    exit 1
fi

if ! command -v motor_controller_setup.py &> /dev/null
then
    python $PRODUCTION_TOOLS_BASE/cpm/scripts/motor_controller_setup.py
else
    motor_controller_setup.py
fi

status=$?

if [ $status -eq 1 ]
then
    print_colour $RED "\n\n\nerror setting up the motor controllers, check the messages above to identify the error"
    exit 1
fi

echo $PW | sudo -S systemctl start robohive_wemo_platform_node.service

print_colour $GREEN "\n\n\n\nUpgrade completed"
exit 0
