#!/bin/bash

# Locate production tools base folder, releative to the path containing this script ($0)
SCRIPT_DIR=$(dirname $(readlink -f $0))
PRODUCTION_TOOLS_BASE=$(readlink -f $SCRIPT_DIR/../..) # Update if moved to shallow/deeper dir

source $PRODUCTION_TOOLS_BASE/config.cfg
source $PRODUCTION_TOOLS_BASE/console_tools/print_tools.bash --source-only
source $PRODUCTION_TOOLS_BASE/console_tools/test_tools.bash --source-only

PW=$(echo $WEMO_ACCESS | base64 -d | gpg --decrypt --pinentry-mode loopback --passphrase $GPG_PASSPHRASE 2>/dev/null)

test_internal

if ! command -v lift_communications.py &> /dev/null
then
    python3 $PRODUCTION_TOOLS_BASE/general_assembly/scripts/lift_communications.py
else
    lift_communications.py
fi

status=$?

if [ $status -eq 1 ]
then
    print_colour $RED "\n\n\ncommunication error, check the messages above to identify the error"
    exit 1
fi

if ! command -v lift.py &> /dev/null
then
    python3 $PRODUCTION_TOOLS_BASE/general_assembly/scripts/lift.py
else
    lift.py
fi

status=$?

if [ $status -eq 1 ]
then
    print_colour $RED "\n\n\nerror while attempting to control the lift, check the messages above to identify the error"
    exit 1
fi

echo $PW | sudo -S systemctl start robohive_wemo_platform_node.service

print_colour $GREEN "\n\n\n\nTest finished successfuly"
exit 0
