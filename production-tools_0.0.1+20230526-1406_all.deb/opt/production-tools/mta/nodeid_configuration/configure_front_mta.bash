#!/bin/bash

# Locate console_tools, releative to the path containing this script ($0)
SCRIPT_DIR=$(dirname $(readlink -f $0))
PRODUCTION_TOOLS_BASE=$(readlink -f $SCRIPT_DIR/../..) # Update if moved to shallow/deeper dir

source $PRODUCTION_TOOLS_BASE/config.cfg --source-only
PW=$(echo $WEMO_ACCESS | base64 -d | gpg --decrypt --pinentry-mode loopback --passphrase $GPG_PASSPHRASE 2>/dev/null)

echo "Initialising"
echo $PW | sudo -S ip link set down can0 && echo $PW | sudo -S ip link set can0 type can bitrate 500000 && echo $PW | sudo -S ip link set up can0
status=$?

if [ $status -eq 1 ]
then
    echo "CAN adapter disconnected, please check the USB connection"
    exit 1
fi

cansend can0 000#8100
sleep 15

if ! command -v mta_lss_configure.py &> /dev/null
then
    python3 $PRODUCTION_TOOLS_BASE/mta/nodeid_configuration/mta_lss_configure.py --i 2
else
    mta_lss_configure.py --i 2
fi

if [ $? != 0 ] ; then
    echo $PW | sudo -S ip link set down can0 && echo $PW | sudo -S ip link set can0 type can bitrate 1000000 && echo $PW | sudo -S ip link set up can0
    cansend can0 000#8100
    sleep 15

    if ! command -v mta_lss_configure.py &> /dev/null
    then
        python3 $PRODUCTION_TOOLS_BASE/mta/nodeid_configuration/mta_lss_configure.py --i 2
    else
        mta_lss_configure.py --i 2
    fi

    if [ $? != 0 ] ; then
        echo "Failed during LSS configuration. Please create a report with the output of the command"
        exit 1
    fi
fi

cansend can0 000#8100
echo $PW | sudo -S ip link set down can0 && echo $PW | sudo -S ip link set can0 type can bitrate 1000000 && echo $PW | sudo -S ip link set up can0
sleep 15
echo "Front motor successfully configured"

exit 0
