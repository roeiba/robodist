
# Locate console_tools, releative to the path containing this script ($0)
set SCRIPT_DIR=$(dirname $(readlink -f $0))
set PRODUCTION_TOOLS_BASE=$(readlink -f $SCRIPT_DIR/..) # Update if moved to shalowe/deeper dir

source $PRODUCTION_TOOLS_BASE/config.cfg
PW=$(echo $WEMO_ACCESS | base64 -d | gpg --decrypt --pinentry-mode loopback --passphrase $GPG_PASSPHRASE 2>/dev/null)

test_local_usb_network() {
    source $PRODUCTION_TOOLS_BASE/console_tools/print_tools.bash --source-only
    printf "\nTesting local connection (192.168.55.1)...\n"
    ping 192.168.55.1 -c1 > /dev/null 2>&1
    status=$?

    if [ $status -ne 0 ]
    then

        print_colour $RED "Unable to connect to WeMo via local USB (192.168.55.1) \n"

        printf "1. WeMo may need up to a minute to register ssh/ping over usb.\n"
        printf "2. Power cycle WeMo with USB cable already plugged in.\n"
        printf "3. Ensure USB connection to Xavier is secure. Cable should run from your laptop, to the Debug Port, through the WeMo chassis, and to the Xavier.\n"
        printf "4. Xavier may not be flashed with the proper IP address (reflash).\n"

        printf "\n"
        exit 1
    fi
}

test_wireless_network() {
    hostname="$1"
    . ~/production_tools/console_tools/print_tools.bash --source-only
    printf "\nTesting local connection ($hostname)...\n"
    ping $hostname -c1 > /dev/null 2>&1
    status=$?

    if [ $status -ne 0 ]
    then

        print_colour $RED "Unable to connect to WeMo via wireless ($hostname) \n"

        printf "1. WeMo may be off.\n"
        printf "2. WeMo may not be connected to the internet.\n"
        printf "3. Laptop may not be in 'robo' network.\n"

        printf "\n"
        exit 1
    fi
}

run_script_over_usb() {
    test_local_usb_network

    filename=$1
    sshpass -p $PW ssh hive@192.168.55.1 sh $filename
}

run_script_over_wireless() {
    echo -n "wemo to be tested: ";
    read wemo_name;
    wemo_hostname="${wemo_name}.local"
    test_wireless_network $wemo_hostname

    # clean the ssh keys
    ip=`ping $wemo_hostname -c1 | grep -w 'from' | awk '{print $4}'`
    ssh-keygen -R $ip > /dev/null 2>&1
    ssh-keygen -R $wemo_hostname > /dev/null 2>&1
    ssh-keyscan -H $wemo_hostname >> ~/.ssh/known_hosts

    filename=$1
    sshpass -p $PW ssh hive@$wemo_hostname sh $filename
}

test_internal() {
    source $PRODUCTION_TOOLS_BASE/console_tools/print_tools.bash --source-only
    source $PRODUCTION_TOOLS_BASE/console_tools/can_tools.bash --source-only

    echo $PW | sudo -S systemctl stop robohive_wemo_platform_node.service

    if ! command -v battery_level_check.py &> /dev/null
    then
        python $PRODUCTION_TOOLS_BASE/hardware_interface/examples/battery_level_check.py -b 50
    else
        battery_level_check.py -b 50
    fi

    status=$?

    if [ $status -eq 1 ]
    then
        print_colour $RED "\n\n\nbattery level is under the desired value, please charge the robot and try later"
        exit 1
    fi

    configure_can can0 1000000
    status=$?

    if [ $status -eq 1 ]
    then
        exit 1
    fi

    configure_can can1 250000
    status=$?

    if [ $status -eq 1 ]
    then
        exit 1
    fi

    # HACK
    # Ref: MROBOT-4806
    if [ -h /sys/class/net/eth5 ]; then
        echo $PW | sudo -S ifconfig eth5 192.168.1.102 netmask 255.255.255.0
    elif [ -h /sys/class/net/eth6 ]; then
        echo $PW | sudo -S ifconfig eth6 192.168.1.102 netmask 255.255.255.0
    else
        echo $PW | sudo -S ifconfig eth0 192.168.1.102 netmask 255.255.255.0
    fi

    status=$?

    if [ $status -ne 0 ]
    then
        print_colour $RED "\n\n\nethernet cannot be configured, please notify it as soon as possible"
        exit 1
    fi
}

#https://mike632t.wordpress.com/2017/07/06/bash-yes-no-prompt/
yes_or_no() {
  local _prompt _default _response

  if [ "$1" ]; then _prompt="$1"; else _prompt="Are you sure"; fi
  _prompt="$_prompt [y/n] ?"

  # Loop forever until the user enters a valid response (Y/N or Yes/No).
  while true; do
    read -r -p "$_prompt " _response
    case "$_response" in
      [Yy][Ee][Ss]|[Yy]) # Yes or Y (case-insensitive).
        return 1
        ;;
      [Nn][Oo]|[Nn])  # No or N.
        return 0
        ;;
      *) # Anything else (including a blank) is invalid.
        printf "Invalid input: "
        printf "$_response"
        printf "\n"
        ;;
    esac
  done
}
