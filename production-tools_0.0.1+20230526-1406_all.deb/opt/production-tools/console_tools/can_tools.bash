#!/bin/bash

# Locate console_tools, releative to the path containing this script ($0)
set SCRIPT_DIR=$(dirname $(readlink -f $0))
set PRODUCTION_TOOLS_BASE=$(readlink -f $SCRIPT_DIR/..) # Update if moved to shalowe/deeper dir

source $PRODUCTION_TOOLS_BASE/config.cfg
source $PRODUCTION_TOOLS_BASE/console_tools/print_tools.bash --source-only

PW=$(echo $WEMO_ACCESS | base64 -d | gpg --decrypt --pinentry-mode loopback --passphrase $GPG_PASSPHRASE 2>/dev/null)

is_iface_configured() {
    interface=$1
    ifconfig $interface > /dev/null 2>&1
    status=$?
    if [ $status -ne 1 ]
    then
        # the interface is detected and configured
        return 0
    else
        # the interface is not detected or configured
        return 1
    fi
}

is_baudrate_correct() {
    interface=$1
    desired_baudrate=$2

    is_iface_configured $interface
    if [ $? -eq 1 ]
    then
        return 1
    fi

    configured_baudrate=`ip -det link show $interface | grep bitrate | awk '{print $2}'`

    if [ -z $configured_baudrate ]
    then
        return 1
    fi

    if [ $configured_baudrate -eq $desired_baudrate ]
    then
        return 0
    else
        return 1
    fi
}

configure_can() {
    interface=$1
    baudrate=$2

    is_iface_configured $interface
    is_iface_configured_ret=$?
    is_baudrate_correct $interface $baudrate
    is_baudrate_correct_ret=$?

    if [ $is_iface_configured_ret -eq 0 -a $is_baudrate_correct_ret -eq 0 ]
    then
        return 0
    fi

    ARCH=`dpkg --print-architecture`

    if [ "${ARCH}" == "arm64" ]
    then
        echo $PW | sudo -S modprobe mttcan
    fi

    echo $PW | sudo -S ip link set down $interface && echo $PW | sudo -S ip link set $interface type can bitrate $baudrate restart-ms 100 && echo $PW | sudo -S ip link set up $interface
    status=$?

    if [ $status -eq 1 ]
    then
        print_colour $RED "\n\n\n$interface interface not recognised, please notify it as soon as possible"
        return 1
    else
        return 0
    fi

}
