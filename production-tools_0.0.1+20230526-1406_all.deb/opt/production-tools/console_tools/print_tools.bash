#!/bin/bash


RED='\033[0;31m'
GREEN='\033[0;32m'
NC='\033[0m' # No Color

print_colour() {
    color=$1
    string=$2
    printf "${color}${string}${NC}\n"
}

print_link() {
    uri="$1"
    label="$2"

    printf '\e]8;;'$uri'\a'$label'\e]8;;\a'
}