#!/bin/bash

# Locate production tools base folder, releative to the path containing this script ($0)
SCRIPT_DIR=$(dirname $(readlink -f $0))
PRODUCTION_TOOLS_BASE=$(readlink -f $SCRIPT_DIR/../..) # Update if moved to shallow/deeper dir

source $PRODUCTION_TOOLS_BASE/config.cfg
source $PRODUCTION_TOOLS_BASE/console_tools/print_tools.bash --source-only
source $PRODUCTION_TOOLS_BASE/console_tools/test_tools.bash --source-only

PW=$(echo $WEMO_ACCESS | base64 -d | gpg --decrypt --pinentry-mode loopback --passphrase $GPG_PASSPHRASE 2>/dev/null)

test_internal

# TODO Jose
#ARCH=$(arch)
#if [[ "$ARCH" == "x86_64" ]]; then
#    $PRODUCTION_TOOLS_BASE/tools/openblt_${OPENBLT_VERSION}_src_amd64/Host/BootCommander -s=xcp -t=xcp_can -d=can1 -c=0 -b=250000 -tid=503 -rid=483 $PRODUCTION_TOOLS_BASE/cpm/firmware/wemo_pdb.srec
#else
#    $PRODUCTION_TOOLS_BASE/tools/openblt_arm64/Host/BootCommander -s=xcp -t=xcp_can -d=can1 -c=0 -b=250000 -tid=503 -rid=483 $PRODUCTION_TOOLS_BASE/cpm/firmware/wemo_pdb.srec
#fi
#
#status=$?

#if [ $status -eq 1 ]
#then
#    print_colour $RED "\n\n\nerror flashing the PDB MCU, check the messages above to identify the error"
#    exit 1
#fi

if ! command -v configure_motor_controller.py &> /dev/null
then
    python3 $PRODUCTION_TOOLS_BASE/cpm/scripts/configure_motor_controller.py
else
    configure_motor_controller.py
fi

status=$?

if [ $status -eq 1 ]
then
    print_colour $RED "\n\n\nerror setting up the motor controllers node id and baudrate, check the messages above to identify the error"
    exit 1
fi

if ! command -v motor_controller_setup.py &> /dev/null
then
    python3 $PRODUCTION_TOOLS_BASE/cpm/scripts/motor_controller_setup.py
else
    motor_controller_setup.py
fi

status=$?

if [ $status -eq 1 ]
then
    print_colour $RED "\n\n\nerror setting up the motor controllers, check the messages above to identify the error"
    exit 1
fi

echo $PW | sudo -S systemctl start robohive_wemo_platform_node.service


print_colour $GREEN "\n\n\n\nConfiguration finished successfuly"
exit 0
